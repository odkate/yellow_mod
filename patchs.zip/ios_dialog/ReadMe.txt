Заголовок: apkfuck/alertdialog/IOSdialog.smali строка: 49
Сообщение: apkfuck/alertdialog/IOSdialog.smali строка: 25
Кнопка для закрытие диалога: apkfuck/alertdialog/IOSdialog.smali строка: 33
Кнопка со ссылкой: apkfuck/alertdialog/IOSdialog.smali строка: 41
Ссылка: apkfuck/alertdialog/IOSdialog.smali строка: 17
Количество для показания: apkfuck/alertdialog/IOSdialog.smali строка: 80 (const/16 v0, 0x1 # сейчас 1 раз)
Для бесконечной показание: apkfuck/alertdialog/IOSdialog.smali строка: 57 (const/4 v0, 0x0 замените на const/4 v0, 0x1)